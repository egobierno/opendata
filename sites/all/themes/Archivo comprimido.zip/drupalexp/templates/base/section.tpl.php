<section <?php print $attributes;?>>
	<div class="<?php print $container_class;?>">
		<div class="row">
			<?php print $content; ?>
		</div>
	</div>
</section>