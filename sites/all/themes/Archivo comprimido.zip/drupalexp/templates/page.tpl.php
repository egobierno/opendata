<?php
	$theme = drupalexp_get_theme();
	print $theme->pageRender();
?>
<!--page rendered by drupalexp drupal theme framework-->