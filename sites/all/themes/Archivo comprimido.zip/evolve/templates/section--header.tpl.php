<section <?php print $attributes;?>>
	<div class="<?php print $container_class;?>">
		<div class="row">
			<div class="hidden-lg hidden-md col-xs-3 col-sm-3"><span class="fa fa-bars menu-toggle"></span></div>
      <?php print $content; ?>
		</div>
	</div>
</section>