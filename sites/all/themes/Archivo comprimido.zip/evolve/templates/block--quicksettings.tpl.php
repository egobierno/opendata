<?php
print 'custom quicksettings';