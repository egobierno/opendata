If using Method 1, this folder is where the output from the compiled LESS files
should be generated. If using the LESS module, this folder can be ignored or
removed.

If using Method 2, edit the style.css file to your liking.
