<?php
/**
 * @file
 * bootstrap-dropdown.func.php
 */

/**
 * Renders the Bootstrap dropdown.
 */
function bootstrap_bootstrap_dropdown($variables) {
  return drupal_render($variables['dropdown']);
}
