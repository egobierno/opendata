<header<?php print $attributes; ?>>
  <?php print $content; ?>
</header>