
This directory should be used to place nodes template files.
