
This directory should be used to place user template files.
