
This directory should be used to place contrib modules template files.
