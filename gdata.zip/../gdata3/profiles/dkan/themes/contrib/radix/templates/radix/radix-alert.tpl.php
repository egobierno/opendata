<?php
/**
 * @file
 * Template file for Radix Alert.
 */
?>
<div class="<?php print $classes; ?>">
  <?php print $text; ?>
</div>
